import{bU as i,d as s,k as t,dn as a}from"./index-CyMr76_m.js";const d={view:a},r=new i(d,(o,e)=>({...o,dispatch:e})).setPropertyViewFn(()=>s(t,{})).build();export{r as ContainerBodyChildComp};
