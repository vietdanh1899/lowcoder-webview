import{h0 as e,dn as o}from"./index-CyMr76_m.js";const s=e(o);class a extends s{}export{a as ContextContainerComp};
