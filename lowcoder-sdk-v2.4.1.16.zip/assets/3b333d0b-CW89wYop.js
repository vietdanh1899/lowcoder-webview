import{a4 as n,bU as a,as as i,k as l,aj as t,bw as e,bT as p}from"./index-CyMr76_m.js";n.div`
  display: flex;
  justify-content: space-between;
  .hUXIwu {
    flex: 0 0 36px;
  }
  .fgbLEe {
    margin-right: 5px;
    margin-bottom: 10px;
  }
`;const s=function(){const r={left:e(p,""),right:e(p,""),top:e(p,""),bottom:e(p,"")};return new a(r,o=>o).setPropertyViewFn(o=>i(l,{children:[o.top.propertyView({label:t("componentDoc.top")}),o.right.propertyView({label:t("componentDoc.right")}),o.bottom.propertyView({label:t("componentDoc.bottom")}),o.left.propertyView({label:t("componentDoc.left")})]})).build()}();export{s as MarginControl};
