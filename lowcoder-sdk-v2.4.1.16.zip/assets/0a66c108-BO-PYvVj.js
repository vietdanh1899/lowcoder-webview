import{d as e,k as s,dM as c,a0 as n,cE as t}from"./index-CyMr76_m.js";function o(a,r){return e(s,{children:c()?e(n.Suspense,{fallback:e(t,{}),children:a}):r})}export{o as useUIView};
